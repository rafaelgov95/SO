

//
// Created by rafael on 12/01/17.
//

#include <zconf.h>
#include <cstdlib>
#include <iostream>
#include <cstring>
#include "Cozinheiro.h"

using namespace std;

Cozinheiro::Cozinheiro() {
    if (!pipe(fd)) {
        if (fork() == 0) {
            pid = getpid();
            anotarPedido();
        }
    }
}

void Cozinheiro::anotarPedido() {
    close(fd[1]);
    memset(temp, 0, sizeof(temp));
    int n = 0;
    while ((n = read(fd[0], &temp, sizeof(temp))) > 0) {
        write(STDOUT_FILENO, &temp, sizeof(temp));
        cout << endl << n << endl;
    }
    cout << n << endl;
    cout << "fechou" << endl;
    close(fd[0]);
}

void Cozinheiro::ouvirPedido(const string &pedido) {
    close(fd[0]);
    cout << "Enviando para o pipe do Cozinheiro " << endl;
    write(fd[1], pedido.c_str(), pedido.size());
    close(fd[1]);

}

pid_t Cozinheiro::getPid() {
    return pid;
}



