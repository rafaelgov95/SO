//
// Created by rafael on 12/01/17.
//

#ifndef UNTITLED_MESA_H
#define UNTITLED_MESA_H

using namespace std;

class Mesa {
private:
    int id;
    vector<>;
public:

    int  getId();
};


#endif //UNTITLED_COZINHEIRO_H
