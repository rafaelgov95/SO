#include <iostream>
#include <zconf.h>
#include <cstring>

using namespace std;

#include "Cozinheiro.h"

Cozinheiro *coz[10];
int messas[18];

int BuscarCozinheiro(int b) {
    if (coz[b] != nullptr) return b;
    return 0;
}

int MesaDisponivel() {
    for (int i = 0; i < sizeof(coz); ++i) {
        if (coz[i] == nullptr) return i;
    }
    return -1;
}

int main() {
    bool flag = true;
    int id = -1;
    string pedido;
    char temp[1024];

    Cozinheiro *coz = new Cozinheiro();
    coz->ouvirPedido("Quero batata frita!");

    while(1);


//    while (flag) {
//        cin >> id >> pedido;
//        if (BuscarCozinheiro(id)) {
//            coz[id]->ouvirPedido(pedido);
//        } else {
//            int index = MesaDisponivel();
//            coz[index] = new Cozinheiro();
//
//
//        }
//    }
}






