

//
// Created by rafael on 12/01/17.
//

#include <zconf.h>
#include <cstdlib>
#include <iostream>
#include <cstring>
#include "Cozinheiro.h"

using namespace std;

Mesa::Mesa() {



}


int  Cozinheiro::getid() {
    return id;
}



