#include <iostream>
#include "Restaurante.h"

using namespace std;
Restaurante R;

int main() {
    R.iniciarRestaurante();
}








